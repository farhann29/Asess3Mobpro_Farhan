package com.farhanfad0036.asses3olshop.model

data class OpStatus(
    val status: String,
    var message: String?
)
