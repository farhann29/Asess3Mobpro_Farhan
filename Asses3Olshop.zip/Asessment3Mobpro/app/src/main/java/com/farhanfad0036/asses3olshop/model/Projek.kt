package com.farhanfad0036.asses3olshop.model

data class Projek(
    val id: Long,
    val semester: String,
    val mataKuliah: String,
    val gambar: String,
    val mine: Int
)
